### A Cute Way to get a Girlfriend

A cute mobile site, built to ask a girl to be my girlfriend.  

![laurasite](https://user-images.githubusercontent.com/6922982/39973370-04228616-56d4-11e8-8eb1-e86dc843d3ac.gif)


#### Usage:
```
npm install
npm start
```
 
